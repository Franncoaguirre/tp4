var numeros=[460,460,460,345,230,600,130,1200,500,460];
document.write(numeros.join(" - "));
document.write("<br>");
var distintos = numeros.filter((numeros)=>numeros!=460);
document.write(distintos);